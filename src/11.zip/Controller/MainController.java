package Controller;
import Service.DisplayMenu;

public class MainController {

    public static void main(String[] args) {
      
    	
    	
    	DisplayMenu disPlayMenu = new DisplayMenu();
        disPlayMenu.defaultMenu();
    }
}
