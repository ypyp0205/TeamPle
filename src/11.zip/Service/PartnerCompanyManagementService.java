package Service;

public interface PartnerCompanyManagementService {
    public void addPartnerCompany();
    public void deletePartnerCompany();
    public void getPartnerList();
}
