package Service;

public interface BusinessService {
    public void addTrade();
    public void deleteTrade();
    public void showTradeHistory();

}
