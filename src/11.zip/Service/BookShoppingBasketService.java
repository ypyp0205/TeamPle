package Service;

public interface BookShoppingBasketService {
    public void addBookShoppingBasket();

    public void bookShoppingBasketMenu();

    public void removeBookName();
    public void bookShoppingBasketList();
}
