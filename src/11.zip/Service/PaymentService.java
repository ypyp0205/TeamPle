package Service;

public interface PaymentService {
    public void payList();
    public void pay();
}
