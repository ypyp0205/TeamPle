package Service;

public interface UserService {
    public void addUser();
    public void deleteUser();
    public void ListUser();
    public void myPage();
}
